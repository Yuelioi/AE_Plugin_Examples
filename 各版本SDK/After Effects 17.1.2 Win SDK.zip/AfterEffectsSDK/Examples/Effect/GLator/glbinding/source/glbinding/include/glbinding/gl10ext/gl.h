#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl10ext/types.h>
#include <glbinding/gl10ext/boolean.h>
#include <glbinding/gl10ext/values.h>
#include <glbinding/gl10ext/bitfield.h>
#include <glbinding/gl10ext/enum.h>
#include <glbinding/gl10ext/functions.h>
