#pragma once

#include <glbinding/nogl.h>
#include <glbinding/gl/values.h>


namespace gl21
{




} // namespace gl21
