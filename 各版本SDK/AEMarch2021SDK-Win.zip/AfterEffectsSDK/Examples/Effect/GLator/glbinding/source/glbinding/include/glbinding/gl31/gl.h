#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl31/types.h>
#include <glbinding/gl31ext/types.h>
#include <glbinding/gl31/boolean.h>
#include <glbinding/gl31ext/boolean.h>
#include <glbinding/gl31/values.h>
#include <glbinding/gl31ext/values.h>
#include <glbinding/gl31/bitfield.h>
#include <glbinding/gl31ext/bitfield.h>
#include <glbinding/gl31/enum.h>
#include <glbinding/gl31ext/enum.h>
#include <glbinding/gl31/functions.h>
#include <glbinding/gl31ext/functions.h>
